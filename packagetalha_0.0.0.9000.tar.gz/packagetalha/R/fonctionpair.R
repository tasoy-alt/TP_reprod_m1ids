#' Verifie si un nombre est pair selon la methode de Talha
#'@param n entier
#'@return logical
#'
#'
#'@export

nombre_pair<-function(n)

{
  if (n%%2==0)
    return(TRUE)
  else
    return(FALSE)
}

